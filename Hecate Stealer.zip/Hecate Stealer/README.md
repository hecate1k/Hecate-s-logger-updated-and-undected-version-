<h1 align="center"> Hecate Stealer </h1> 
<p align= "center"> <kbd> <img  src="https://images-ext-1.discordapp.net/external/IlKyD0iPMzyFS2SmspnSVUsUMx-7NRjhVQoNZnGro4E/https/cdn.discordapp.com/avatars/873284425314623578/a_6a485b7a96e8cdf89aef64f2dc793c59?width=102&height=102"width="400"> </kbd><br><br>

<p></p>
<p> if you need help you can e-mail / dm me on disc: compile#3030 or tonyphamusanew@gmail.com </p>


## Features:
» Grab Discord Information and HQ Friends.

» Grab Password & cookies.

» Grab Files.

» Shows Crypto Wallets

» Grab metamask/exodus

» Grab Telegram

» Grab chromium based Passwords


## Setup:
 
First paste and save your webhook address instead of `"WEBHOOK HERE"` in Hecate Logger.py

If you use obfuscator it will be undetectable.

if you have an error while installing try `pip install -r requirements.txt`

Now You need to use pyinstaller to convert python file to exe.

Open CMD and type `pip install auto_py_to_exe`

And after installed `python -m auto_py_to_exe`

Browse file Select `One file and Windows Based (hide the console)`

<img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/pyy.png"></img>

And press covert .py .exe

 <hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

## Pictures:
 
<img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/CrealNew1.jpg"></img>

<img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/CrealNew2.png"></img>

<img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/CrealNew3.png"></img>
 
 
## Disclaimer:

This tool is for educational purposes only. It is coded for you to see how your files are simply stolen and how to take action. Do not use for illegal purposes. We are never responsible for illegal use. <bold>Educational purpose only!</bold>

## License:
By downloading this, you agree to the Commons Clause license and that you're not allowed to sell this repository or any code from this repository. For more info see https://commonsclause.com/.

<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">
